import Foundation
final class APIClient { static let shared = APIClient() }