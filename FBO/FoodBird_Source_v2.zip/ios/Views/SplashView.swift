import SwiftUI
struct SplashView: View { var body: some View { Text("Splash") } }