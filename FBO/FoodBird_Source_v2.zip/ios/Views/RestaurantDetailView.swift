import SwiftUI
struct RestaurantDetailView: View { var body: some View { Text("Detail") } }