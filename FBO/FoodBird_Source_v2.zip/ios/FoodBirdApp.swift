import SwiftUI
@main struct FoodBirdApp: App { var body: some Scene { WindowGroup { Text("FoodBird") } } }