import Foundation
struct Restaurant: Identifiable, Codable { let id: String; let name: String }