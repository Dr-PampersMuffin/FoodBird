import Foundation
enum BuildConfig { static let API_BASE_URL = URL(string: "http://localhost:8000")! }