from fastapi import FastAPI
app = FastAPI()
@app.get('/restaurants')
def restaurants():
    return []
